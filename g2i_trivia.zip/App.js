import * as React from "react";
import Routes from "./routes";

export default function App() {
  return <Routes />;
}
